﻿using System.IO;
using System;
using System.Drawing;

namespace part1_attempt_4
{
    public class logo_design
    {
        public logo_design()
        { // get full location of project
            string full_location = AppDomain.CurrentDomain.BaseDirectory;

            // replace the bin\debug folder in the full_location
            string new_location = full_location.Replace("bin\\Debug\\", "");

            // combine the paths
            string full_path = Path.Combine(new_location, "cyber_security_logo.jpg");

            // then time to use ascii

            // creating the BitMap class
            Bitmap image = new Bitmap(full_path);

            // then set the size
            image = new Bitmap(image, new Size(150, 150));

            // outer and inner loop
            for (int height = 0; height < image.Height; height++)
            {
                // inner loop
                for (int width = 0; width < image.Width; width++)
                {
                    Color pixelColor = image.GetPixel(width, height);
                    int gray = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                    char asciiChar = gray > 200 ? '-' : gray > 150 ? '*' : gray > 100 ? 'o' : gray > 50 ? '#' : '@';
                    Console.Write(asciiChar);

                } // end of inner loop
                Console.WriteLine();
            } // end of outer loop

        }
    }
}