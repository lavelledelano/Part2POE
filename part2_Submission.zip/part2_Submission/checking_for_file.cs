﻿using System.Collections.Generic;
using System.IO;
using System;

namespace part1_attempt_4
{
    public class checking_for_file
    {
        public checking_for_file()
        {

            Console.Write("  Only if you'd like to: "); Console.WriteLine(" ");
            Console.Write("  Please enter your favorite topic so i can store it in my memory: ");
            string userInput = Console.ReadLine();

            // get app path
            string full_path = AppDomain.CurrentDomain.BaseDirectory;
            string new_path = full_path.Replace("bin\\Debig\\", "");
            string path = Path.Combine(new_path, "classonememory.txt");

            // check memory
            var classonememory = loadMemory(path);

            // check all stored
            foreach (var check in classonememory)
            {
                Console.WriteLine(check);
            }

            classonememory.Add(userInput);


            // then save
            File.WriteAllLines(path, classonememory);


        }// end of constructor

        // method to load memory and to check if the file exists
        private List<string> loadMemory(string path)
        {
            // check if the file exists
            if (File.Exists(path))
            {
                // then returns all values or data in file
                return new List<string>(File.ReadAllLines(path));

            }
            else
            {
                // create the file now
                File.CreateText(path);
                return new List<string>();
                Console.WriteLine("file is safely stored in bin\\debug folder under 'classonememory'. ");
            }

        }// end of memory method
    }
    }
